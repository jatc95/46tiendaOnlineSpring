package filtros;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FiltroLogin implements Filter{


	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain fc) throws IOException, ServletException {
		//Este es el codigo que se va a ejecutar cuando el filtro act�e
		//El rec y res que recibo no son los del tipo que estoy acostumbrado a usar en los servlet
		//por eso lo primero que hago es un casting al tipo request y response que estamos
		//acostumbreados a usar en servlets
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		
		if(request.getParameter("passAdmin") != null && request.getParameter("passAdmin").equals("admin")){
			//esto es que se ha introducido la contrase�a correcta en el formulario de login de admin
			request.getSession().setAttribute("admin", "ok");
		}
		
		//voy a entender que el administrador est� identificado si en la sesi�n est� metido
		//un string llamado admin y que valga ok
		if(request.getSession().getAttribute("admin") != null && request.getSession().getAttribute("admin").equals("ok")){
			//esto es que el admin est� identificado
			fc.doFilter(req, res);
		}else{
			//esto es que el admin a�n no se ha identificado
			RequestDispatcher rd = request.getRequestDispatcher("/admin/login2.jsp");
			rd.forward(req, res);
		}
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
