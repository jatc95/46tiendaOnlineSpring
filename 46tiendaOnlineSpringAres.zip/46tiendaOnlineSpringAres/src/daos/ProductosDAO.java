package daos;

import java.util.List;

import modelo.Producto;
import modelo.Usuario;

public interface ProductosDAO {
	
	int registrarProducto(Producto p);
	
	List<Producto> obtenerProductos();
	
	void borrarProducto (int id);
	
	Producto obtenerProductoPorId (int id);
	
	void actualizarProducto (Producto p);
	
	List<Producto> obtenerProductos (int comienzo, int cuantos);
	
	int obtenerTotalProductos();
	
}
