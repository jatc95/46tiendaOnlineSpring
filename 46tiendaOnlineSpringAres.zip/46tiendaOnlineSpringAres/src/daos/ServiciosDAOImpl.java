package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Servicio;

public class ServiciosDAOImpl implements ServiciosDAO{
	
	private DataSource dataSource1;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getElDataSource(){
		return dataSource1;
	}
	
	@Override
	public void registrarServicio(Servicio s) {
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", s.getNombre());
		valores.put("descripcion", s.getDescripcion());
		valores.put("precio", s.getPrecio());
		simpleInsert.execute(valores);
		
	}

	@Override
	public List<Servicio> obtenerServicios() {
		String sql = ConstantesSQL.SQL_SELECCION_SERVICIOS;
		List<Servicio> servicios = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Servicio.class));
		return servicios;
	}
	
	public void setDataSource (DataSource dataSource1) {
		this.dataSource1 = dataSource1;
		simpleInsert = new SimpleJdbcInsert(dataSource1);
		simpleInsert.setTableName("tabla_servicios");
		jdbcTemplate = new JdbcTemplate(dataSource1);
	}
	
}
