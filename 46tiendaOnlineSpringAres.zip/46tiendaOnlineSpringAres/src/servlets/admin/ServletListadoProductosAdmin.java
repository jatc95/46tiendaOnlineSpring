package servlets.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;


@WebServlet("/admin/ServletListadoProductosAdmin")
public class ServletListadoProductosAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//ahora hacemos lo mismo que cuando 
		//hemos listado usuarios
		//pedir el dao al contenedor de spring
		//y mandarle los productos a listadoProductos.jsp
		//para que los muestre
		WebApplicationContext contenedor = 
				ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		
		int comienzo = 0;
		int cuantos = 10;
		
		if(request.getParameter("comienzo") != null){
			comienzo = Integer.parseInt(request.getParameter("comienzo"));
		}
		
		int siguiente = comienzo +10;
		int anterior = comienzo -10;
		
		int total = dao.obtenerTotalProductos();
		
		List<Producto> productos = dao.obtenerProductos(comienzo,cuantos);
		
		
		request.setAttribute("productos", productos);
		request.setAttribute("anterior", anterior);
		request.setAttribute("siguiente", siguiente);
		request.setAttribute("total", total);
		
		RequestDispatcher rd = 
				getServletContext().getRequestDispatcher(
						"/admin/listadoProductos.jsp");
		rd.forward(request, response);	
	}

}
