package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;
import modelo.Servicio;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import daos.ServiciosDAO;

@WebServlet("/admin/ServletRegistroServicio")
public class ServletRegistroServicio extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ServletRegistroServicio() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nombre = request.getParameter("campoNombre");
		String descripcion = request.getParameter("campoDescripcion");
		String precio = request.getParameter("campoPrecio");
		precio = precio.replace(",", ".");
		double precioDouble = Double.parseDouble(precio);
		Servicio nuevo = new Servicio(nombre, descripcion, precioDouble);
		//pedir el dao de productos al contenedor de spring
		//para registrar el nuevo producto
		WebApplicationContext contenedor = 
				ContextLoader.getCurrentWebApplicationContext();
		//asi le pido al contenedor de spring
		//que nos d� la �nica bean que tiene de una clase 
		//que implemente el interfaz Productos dao.
		//En concreto ahora mismo dao, seria la siguiente bean 
		//definida en el xml:
//		<bean id="productosDAO"
//		    	class="daos.ProductosDAOImpl">
//		    	<property name="dataSource" ref="miDataSource" />
//		</bean>
		ServiciosDAO dao = contenedor.getBean(ServiciosDAO.class);
		dao.registrarServicio(nuevo);
		//una vez registrado el producto mostraremos el listado 
		//de productos
		
		RequestDispatcher rd = 
				getServletContext().getRequestDispatcher(
						"/admin/ServletListadoServicios");
		rd.forward(request, response);
	}

}
