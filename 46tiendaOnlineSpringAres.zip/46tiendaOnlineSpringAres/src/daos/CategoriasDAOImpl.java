package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Categoria;
import modelo.Servicio;

public class CategoriasDAOImpl implements CategoriasDAO{
	
	private DataSource dataSource2;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getElDataSource(){
		return dataSource2;
	}
	
	@Override
	public void registrarCategoria(Categoria c) {
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", c.getNombre());
		valores.put("descripcion", c.getDescripcion());
		simpleInsert.execute(valores);
		
	}

	@Override
	public List<Categoria> obtenerCategorias() {
		String sql = ConstantesSQL.SQL_SELECCION_CATEGORIAS;
		List<Categoria> categorias = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Categoria.class));
		return categorias;
	}
	
	public void setDataSource (DataSource dataSource2) {
		this.dataSource2 = dataSource2;
		simpleInsert = new SimpleJdbcInsert(dataSource2);
		simpleInsert.setTableName("tabla_categorias");
		jdbcTemplate = new JdbcTemplate(dataSource2);
	}

}
