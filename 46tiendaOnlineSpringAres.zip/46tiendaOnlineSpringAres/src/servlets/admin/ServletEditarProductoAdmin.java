package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import daos.UsuariosDAO;

@WebServlet("/admin/ServletEditarProductoAdmin")
public class ServletEditarProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		String idPulsado = request.getParameter("id");
		Producto producto = dao.obtenerProductoPorId(Integer.parseInt(idPulsado));
		request.setAttribute("producto", producto);
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin/editarProducto.jsp");
		rd.forward(request, response);
	}

}
