package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import modelo.Producto;

@WebServlet("/admin/ServletGuardarCambiosProductoAdmin")
public class ServletGuardarCambiosProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nombre = request.getParameter("campoNombre");
		String marca = request.getParameter("campoMarca");
		String color = request.getParameter("campoColor");
		String peso = request.getParameter("campoPeso");
		String stock = request.getParameter("campoStock");
		String precio = request.getParameter("campoPrecio");
		String id = request.getParameter("campoId");
		
		Producto productoAeditar = new Producto();
		productoAeditar.setNombre(nombre);
		productoAeditar.setMarca(marca);
		productoAeditar.setColor(color);
		productoAeditar.setPeso(peso);
		productoAeditar.setStock(stock);
		productoAeditar.setPrecio(Double.parseDouble(precio));
		productoAeditar.setId(Integer.parseInt(id));
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		dao.actualizarProducto(productoAeditar);
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin/ServletListadoProductosAdmin");
		rd.forward(request, response);
	}

}
