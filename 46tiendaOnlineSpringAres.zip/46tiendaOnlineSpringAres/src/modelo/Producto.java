package modelo;

public class Producto {

	private String nombre;
	private String marca;
	private String color;
	private String peso;
	private String stock;
	private double precio;
	private int idCategoria;
	private int id;

	public Producto() {
	}

	public Producto(String nombre, String marca, String color, String peso,
			String stock, double precio) {
		super();
		this.nombre = nombre;
		this.marca = marca;
		this.color = color;
		this.peso = peso;
		this.stock = stock;
		this.precio = precio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", marca=" + marca + ", color="
				+ color + ", peso=" + peso + ", stock=" + stock + ", precio="
				+ precio + ", id=" + id + "]";
	}


}
