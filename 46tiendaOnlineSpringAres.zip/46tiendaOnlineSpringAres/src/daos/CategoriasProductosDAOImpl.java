package daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Categoria;
import modelo.CategoriaUsuario;


public class CategoriasProductosDAOImpl implements CategoriasProductosDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private SimpleJdbcInsert simpleInsert;
	
	
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource){
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Categoria> obtenerCategorias() {
		List<Categoria> categoriasProductos = jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_CATEGORIAS, new BeanPropertyRowMapper(Categoria.class));
		return categoriasProductos;
	}
	
	
	
}
