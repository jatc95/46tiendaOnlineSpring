package daos;

import java.util.List;

import modelo.Categoria;
import modelo.CategoriaUsuario;

public interface CategoriasProductosDAO {
	
	List<Categoria> obtenerCategorias();
	
}
