package constantes;

public class ConstantesSQL {

	public final static String SQL_SELECCION_ID_POR_EMAIL_PASS = 
		"select id from tabla_usuarios where email = ? and pass = ? ";
	
	public final static String SQL_SELECCION_USUARIOS = 
		"select * from tabla_usuarios order by id desc";
	
	public final static String SQL_SELECCION_PRODUCTOS = 
			"select * from tabla_productos order by id desc";
	
	public final static String SQL_SELECCION_SERVICIOS =
			"select * from tabla_servicios order by id desc";
	
	public final static String SQL_SELECCION_CATEGORIAS =
			"select * from tabla_categorias order by id desc";
	
	public final static String SQL_BORRAR_USUARIOS =
			"delete from tabla_usuarios where id = ?";
	
	public final static String SQL_OBTENER_USUARIO_POR_ID =
			"select * from tabla_usuarios where id=?";
	
	public final static String SQL_ACTUALIZAR_USUARIO = 
			"update tabla_usuarios set nombre = ?, email = ?, pass = ? where id = ?";
	
	public final static String SQL_BORRADO_PRODUCTOS =
			"delete from tabla_productos where id = ?";
	
	public final static String SQL_OBTENER_PRODUCTO_POR_ID =
			"select * from tabla_productos where id=?";
	
	public final static String SQL_ACTUALIZAR_PRODUCTO =
			"update tabla_productos set nombre = ?, marca = ?, color = ?, peso = ?, stock = ?, precio = ? where id = ?";
	
	public final static String SQL_SELECCION_USUARIO_INICIO_CUANTOS=
			"select * from tabla_usuarios order by id desc limit ?,?;";
	
	public final static String SQL_SELECCION_PRODUCTO_INICIO_CUANTOS =
			"select * from tabla_productos order by id desc limit ?,?;";
	
	public final static String SQL_TOTAL_USUARIOS=
			"select count(*) from tabla_usuarios";
	
	public final static String SQL_TOTAL_PRODUCTOS =
			"select count(*) from tabla_productos";
	
	public final static String SQL_SELECCION_USUARIO_INICIO_CUANTOS_BUSQUEDA =
			"select tu.id, tu.nombre, tu.email, tu.pass, tcu.nombre as nombre_categoria from tabla_usuarios as tu,tabla_categorias_usuario as tcu where tu.idCategoriaUsuario = tcu.id and tu.nombre like ? order by tu.id desc limit ?,?;";
	
	public final static String SQL_TOTAL_USUARIOS_POR_NOMBRE =
			"select count(*) from tabla_usuarios where nombre like ?";
	
	public final static String SQL_SELECCION_CATEGORIAS_USUARIO =
			"select * from tabla_categorias_usuario order by id desc";
}
