package servletsPruebas;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;
import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import daos.UsuariosDAO;

@WebServlet("/ServletRegistraCienProductos")
public class ServletRegistraCienProductos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//servlet que pide el DAO de usuarios a Spring para registrar 100 usuarios y as� poder hacer pruebas
		//con el tema de paginaci�n
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		
		for (int i = 0; i < 100; i++) {
			double peso = 1.2+((double)i/50); 
			String pesoAstring = String.valueOf(peso);
			double precio = 3000-(i*20);
			Producto u = new Producto("cuadro de bicicleta"+i, "Trek", "rojo", pesoAstring, "on", precio);
			dao.registrarProducto(u);
			System.out.println("registrado: "+u.toString());
			
		}//end for
		System.out.println("100 usuarios registrados");
	}//end service

}//end class
