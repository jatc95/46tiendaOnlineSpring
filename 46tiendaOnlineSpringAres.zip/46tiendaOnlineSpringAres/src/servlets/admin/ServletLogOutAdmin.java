package servlets.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/ServletLogOutAdmin")
public class ServletLogOutAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.getSession().invalidate();
		//la siguiente es otro tipo de redirecci�n, las que hemos hecho hasta ahora procesa la
		//peticion yendo de un sitio a otro hasta que al final al usuario le llega la respuesta
		//de una jsp
		
		//esta redireccion responde al usuario que ahora pida otra cosa, en este caso index.jsp
		response.sendRedirect("index.jsp");
	}

}
